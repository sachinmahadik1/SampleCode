﻿using StudentAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentAPI.Interface
{

    public interface IStudents
    {
        Task<IEnumerable<Student>> GetAllStudents();

        Task<int> SaveStudent(Student student);


    }

}
