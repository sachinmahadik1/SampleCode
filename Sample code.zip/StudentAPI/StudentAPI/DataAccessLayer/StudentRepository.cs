﻿using Dapper;
using StudentAPI.Context;
using StudentAPI.Interface;
using StudentAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentAPI.Repository
{
    public class StudentRepository : IStudents
    {

        private readonly DapperContext _context;

        /// <summary>
        /// initialise the Dapper object in constructor
        /// </summary>
        /// <param name="context"></param>
        public StudentRepository(DapperContext context)
        {
            _context = context;
        }


        /// <summary>
        /// get all the students data 
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<Student>> GetAllStudents()
        {
            IEnumerable<Student> students = null;
            try
            {

                using (var connection = _context.CreateConnection())
                {
                    students = await connection.QueryAsync<Student>("GetStudent", commandType: System.Data.CommandType.StoredProcedure);

                }

            }
            catch (Exception ex)
            {
                // We can log error in logfile 
            }
            return students.ToList();

        }


        /// <summary>
        /// Add new student into system
        /// </summary>
        /// <param name="student"></param>
        /// <returns></returns>
        public async Task<int> SaveStudent(Student student)
        {
            int roweffected = 0;
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("FirstName", student.FirstName);
                parameters.Add("LastName", student.LastName);
                parameters.Add("Address", student.Address);

                using (var connection = _context.CreateConnection())
                {
                    roweffected = await connection.ExecuteAsync("SaveStudentData", parameters, commandType: System.Data.CommandType.StoredProcedure);

                }

            }
            catch (Exception ex)
            {
                // We can log error in logfile 
            }
            return roweffected;

        }


    }
}

