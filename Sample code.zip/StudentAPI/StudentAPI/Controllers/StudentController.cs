﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentAPI.Interface;
using StudentAPI.Model;
using StudentAPI.Repository;

namespace StudentAPI.Controllers
{
    [Route("api/Student")]
    [ApiController]
    public class StudentController : ControllerBase
    {

        private readonly IStudents _student;

        /// <summary>
        /// Initialise the interface object
        /// </summary>
        public StudentController(IStudents students)
        {
            _student = students;
        }

        [Route("GetStudentData")]
        [HttpGet]
        public async Task<IEnumerable<Student>> GetStudentData()
        {
            return await _student.GetAllStudents();
        }

        [Route("SaveStudent")]
        [HttpPost]
        public async Task<int> SaveStudent(Student model)
        {
            return await _student.SaveStudent(model);


        }
    }
}