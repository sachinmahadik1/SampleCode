﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASPNETCoreStudentApp.Models;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;

namespace ASPNETCoreStudentApp.Controllers
{
    public class HomeController : Controller
    {

        private HttpClient client = new HttpClient(new HttpClientHandler() { UseDefaultCredentials = true });
        public IActionResult Index()
        {
            return View();
        }


        public IActionResult Student()
        {
            ViewData["Message"] = "Your application Create page.";

            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        /// <summary>
        /// Save new student data 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Student(Student model)
        {
            try
            {
               // Student student = new Student();
                using (var httpClient = new HttpClient())
                {
                    HttpContent contentPost = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
                    
                    // we can get API URL from configuration file 
                    using (var response = await httpClient.PostAsync("https://localhost:44389/api/Student/SaveStudent", contentPost))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        int result = JsonConvert.DeserializeObject<int>(apiResponse);
                    }
                }

            }
            catch (Exception ex)
            {
                // We can log error in logfile 
            }

            return RedirectToAction("AllStudent");
        }


        /// <summary>
        /// Get all student data 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> AllStudent()
        {

            List<Student> liststudent = new List<Student>();
            try
            {
                // we can get API URL from configuration file 
                using (var httpClient = new HttpClient())
                {
                    using (var response = await httpClient.GetAsync("https://localhost:44389/api/student/GetStudentData"))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        liststudent = JsonConvert.DeserializeObject<List<Student>>(apiResponse);
                    }
                }
            }
            catch (Exception ex)
            {
                // We can log error in logfile 
            }

            return View(liststudent);
        }

    }
}



